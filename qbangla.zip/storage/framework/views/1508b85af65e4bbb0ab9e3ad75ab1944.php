<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header text-success ">Customer List</div>
                <div class="card-body">
                    <table class="table-bordered table">
                         <thead>
                              <tr>
                                  <th>SL</th>
                                  <th>Check</th>
                                  <th>Customer Number</th>
                                  <th>Customer Name</th>
                                  <th>Customer Email</th>
                                  <th>Action</th>
                              </tr>
                         </thead>
                      <tbody>
                        <form method="POST" action="<?php echo e(route('checkemailoffer')); ?>">
                            <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($loop->index +1); ?></td>
                               <td>
                                 <input type="checkbox"  name="check[]"  value="<?php echo e($customer->id); ?>" class="form-control">
                              </td>
                              <td><?php echo e($customer->number); ?></td>
                              <td><?php echo e($customer->name); ?></td>
                              <td><?php echo e($customer->email); ?></td>
                              <td>
                                <a href="<?php echo e(route('singlemailoffer',$customer->id)); ?>" class="btn btn-sm btn-success">Send</a>
                              </td>

                          </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <button type="submit"class="btn btn-sm- btn-info">Send Check </button>
                        </td>
                        </form>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\emailoffer.blade.php ENDPATH**/ ?>