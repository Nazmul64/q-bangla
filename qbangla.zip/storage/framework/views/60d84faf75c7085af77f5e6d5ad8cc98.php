<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header">Business List</div>
                 <?php if( session('insert')): ?>
                     <span class="alert alert-success"><?php echo e(session('insert')); ?></span>
                 <?php endif; ?>
                <div class="card-body">
                    <table class=" table table-bordered">
                         <thead>
                              <tr>
                                 <th>Business Tag</th>
                                 <th>Business Title</th>
                                 <th>Business Discription</th>
                                 <th>Business Image</th>
                                 <th>Action</th>
                              </tr>
                         </thead>
                         <tbody>
                            <?php $__currentLoopData = $businesssolution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businesssolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($businesssolution->business_tag); ?></td>
                                  <td><?php echo e($businesssolution->business_title); ?></td>
                                  <td><?php echo e($businesssolution->business_description); ?></td>
                                  <td>
                                     <img  height="90px" src="<?php echo e(asset('frontend/business_photos/'.$businesssolution->business_images)); ?>">
                                  </td>
                                  <td class="d-flex ">
                                    
                                     <a class="btn btn-success"href="<?php echo e(route('category.edit', $businesssolution->id )); ?>">Edit</a>
                                      <a class="btn btn-info mx-1"href="<?php echo e(route('category.show', $businesssolution->id )); ?>">show</a>
                                     <form method="POST"action="<?php echo e(route('category.destroy', $businesssolution->id )); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger mx-1"type="submit">Delete</button>
                                    </form>
                                  </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\admin\business_top\index.blade.php ENDPATH**/ ?>