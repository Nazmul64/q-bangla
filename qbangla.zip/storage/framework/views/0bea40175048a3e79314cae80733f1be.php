<div class="emailoffer">
    <h1>This is Email</h1>
</div>
<style>
    .emailoffer{
        background:rebeccapurple;
        height:250px;
        width:250px
        color:blueviolet
        top:50%;

    }
    .emailoffer h1{
        color:aliceblue;
    }
</style>
<?php /**PATH D:\Q_Bangla\resources\views\email\emailoffers.blade.php ENDPATH**/ ?>