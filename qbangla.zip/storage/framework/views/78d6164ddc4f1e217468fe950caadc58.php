<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header">Data Show</div>
                <div class="card-body">
                   <table class="table table-bordered">
                       <thead>
                        <tr>
                          <th>Goal title</th>
                          <th>Goal description</th>
                          <th>Goal photo</th>
                       </tr>
                       </thead>
                       <tbody>
                            <tr>
                               <td><?php echo e($goal->goal_title); ?></td>
                               <td><?php echo e($goal->goal_description); ?></td>
                               <td>
                                  <img height="150px" src="<?php echo e(asset('frontend/object_photos/'. $goal->goal_photo)); ?>">
                               </td>
                           </tr>
                       </tbody>
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\admin\goal_category\show.blade.php ENDPATH**/ ?>