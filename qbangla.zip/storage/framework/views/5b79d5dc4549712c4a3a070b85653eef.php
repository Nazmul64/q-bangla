<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header">Data Show</div>
                <div class="card-body">
                   <table class="table table-bordered">
                       <thead>
                        <tr>
                          <th>Business Tag</th>
                          <th>Business Title</th>
                          <th>Business Description</th>
                          <th>Business Photo</th>
                       </tr>
                       </thead>
                       <tbody>
                            <tr>
                               <td><?php echo e($businessSolution->business_tag); ?></td>
                               <td><?php echo e($businessSolution->business_title); ?></td>
                               <td><?php echo e($businessSolution->business_description); ?></td>
                               <td>
                                  <img height="150px" src="<?php echo e(asset('frontend/business_photos/'. $businessSolution->business_images)); ?>">
                               </td>
                           </tr>
                       </tbody>
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\admin\business_top\show.blade.php ENDPATH**/ ?>