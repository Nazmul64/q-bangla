<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header">Goal List</div>
                 <?php if( session('insert')): ?>
                     <span class="alert alert-success"><?php echo e(session('insert')); ?></span>
                 <?php endif; ?>
                <div class="card-body">
                    <table class=" table table-bordered">
                         <thead>
                              <tr>
                                 <th>Goal Title</th>
                                 <th>Goal description</th>
                                 <th>Goal Photo</th>
                                 <th>Action</th>
                              </tr>
                         </thead>
                         <tbody>
                            <?php $__currentLoopData = $goalobjective; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goalobjective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($goalobjective->goal_title); ?></td>
                                 <td><?php echo e($goalobjective->goal_description); ?></td>
                                  <td><img height="90px" src="<?php echo e(asset('frontend/object_photos/'.$goalobjective->goal_photo )); ?>"></td>
                                  <td class="d-flex">
                                     <a  href="<?php echo e(route('goal_category.edit',$goalobjective->id )); ?>" class="btn btn-success text-white">Edite</a>
                                      <a  href="<?php echo e(route('goal_category.show',$goalobjective->id )); ?>" class="btn btn-info text-white">Show</a>
                                    <form method="POST"action="<?php echo e(route('goal_category.destroy',$goalobjective->id )); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                       <button type="submit" class="btn btn-danger text-white mx-1">Delete</button>
                                    </form>
                                  </td>
                             </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\admin\goal_category\index.blade.php ENDPATH**/ ?>