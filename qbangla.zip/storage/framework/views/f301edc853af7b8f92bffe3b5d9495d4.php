<?php $__env->startSection('breadcrumb'); ?>
 <div class="page-title-right">
    <ol class="breadcrumb m-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li class="breadcrumb-item active">Starter</li>
    </ol>
</div>
  <h4 class="page-title">Starter page</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
             <div class="col-md-12">
            <div class="card">
                <div class="card-header">Business List</div>
                 <?php if( session('insert')): ?>
                     <span class="alert alert-success"><?php echo e(session('insert')); ?></span>
                 <?php endif; ?>
                <div class="card-body">
                    <table class=" table table-bordered table-responsive">
                         <thead>
                              <tr>
                                 <th>solution_title</th>
                                 <th>solution_description</th>
                                 <th>solution_one</th>
                                 <th>solution_two</th>
                                 <th>solution_three</th>
                                 <th>solution_four</th>
                                 <th>solution_photo</th>
                                 <th>Action</th>
                              </tr>
                         </thead>
                         <tbody>
                            <?php $__currentLoopData = $businesshere; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businesshere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($businesshere->solution_title); ?></td>
                                  <td><?php echo e($businesshere->solution_description); ?></td>
                                  <td><?php echo e($businesshere->solution_one); ?></td>
                                  <td><?php echo e($businesshere->solution_two); ?></td>
                                  <td><?php echo e($businesshere->solution_three); ?></td>
                                  <td><?php echo e($businesshere->solution_four); ?></td>
                                  <td>
                                     <img  height="90px" src="<?php echo e(asset('frontend/business_solution/'.$businesshere->solution_photo)); ?>">
                                  </td>
                                  <td class="d-flex">
                                     <a class="btn btn-success text-white"href="<?php echo e(route('businesshere.edit',$businesshere->id)); ?>">Edit</a>
                                      <form method="POST"action="<?php echo e(route('businesshere.destroy',$businesshere->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                       <button class="btn btn-danger text-white mx-1"type="submit">Delete</button>
                                      </form>
                                  </td>

                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Q_Bangla\resources\views\admin\businesshere\index.blade.php ENDPATH**/ ?>